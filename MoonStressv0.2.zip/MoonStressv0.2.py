import tkinter as tk
import socket
import threading
import tkinter.messagebox as mbox

class MoonStress:
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("MoonStress")

        self.label1 = tk.Label(self.window, text="Enter IP to check for ports:")
        self.label1.grid(row=0, column=0, padx=10, pady=10)

        self.ip_entry = tk.Entry(self.window)
        self.ip_entry.grid(row=0, column=1, padx=10, pady=10)

        self.port_check_button = tk.Button(self.window, text="Check open ports", command=self.check_open_ports)
        self.port_check_button.grid(row=1, column=0, padx=10, pady=10)

        self.label2 = tk.Label(self.window, text="Enter IP address:")
        self.label2.grid(row=2, column=0, padx=10, pady=10)

        self.ip_entry2 = tk.Entry(self.window)
        self.ip_entry2.grid(row=2, column=1, padx=10, pady=10)

        self.label3 = tk.Label(self.window, text="Enter port:")
        self.label3.grid(row=3, column=0, padx=10, pady=10)

        self.port_entry = tk.Entry(self.window)
        self.port_entry.grid(row=3, column=1, padx=10, pady=10)

        self.stress_test_button = tk.Button(self.window, text="Infinitly send UDP packets \n (Taskkill  to stop)", command=self.stress_test)
        self.stress_test_button.grid(row=4, column=0, padx=10, pady=10)

        self.window.mainloop()

    def check_open_ports(self):
        ip_address = self.ip_entry.get()
        ports = [21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995]
        open_ports = []
        for port in ports:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((ip_address, port))
                if result == 0:
                    open_ports.append(port)
                sock.close()
            except:
                pass
        if len(open_ports) > 0:
            msg = "The open ports are: " + str(open_ports)
        else:
            msg = "Tough look! No open ports."
        tk.messagebox.showinfo("Any open ports there!?", msg)

    def stress_test(self):
        ip_address = self.ip_entry2.get()
        port = int(self.port_entry.get())
        thread = threading.Thread(target=self.send_udp_packets, args=(ip_address, port))
        thread.start()
        tk.messagebox.showinfo("UDP Packets", "UDP Packets are being sent infinitly (If your internet is slowing down it is due to the rapid UDP sending). To stop taskkill the program.")

    def send_udp_packets(self, ip_address, port):
        while True:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.sendto(b"AAAAAA", (ip_address, port))
            except:
                pass


if __name__ == "__main__":
    tester = MoonStress()
